lst = ['H', 'e', 'l', 'l', 'o', ' ', 'I', 'a', 'T']

lst[7] = 'o'
print(lst)


lst.append('?')
print(lst)

print(len(lst))

print(str(lst))

lst.sort(reverse=True)
print(lst)
